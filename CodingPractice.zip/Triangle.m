size = input("Please enter the size you want: ");

x = "";

for i = 1 : size
    x = x.append("* ");
end

for i = 1 : size
    disp(x);
end