num = randi(100);
guess = input("Guess a number beween 1 and 100: ");

while guess ~= num
    if(guess < num) 
        guess = input("Too Low. Try again: ");
    end
    if(guess > num) 
        guess = input("Too High. Try again: ");
    end
end

disp("Correct!")