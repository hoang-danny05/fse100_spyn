x = input("Enter number: ");
y = input("Enter number: ");

n = x;
if y < n
    n = y;
end

i = 0;
while i < n
    disp(i);
    i = i + 2;
end