amount = input("Enter the check total: ");

for i = 10:5:20
    tip_amount = amount * (i / 100.00);
    [x, err] = sprintf("For %d%%, tip $%0.2f or a total of $%0.2f", [i, tip_amount, amount+tip_amount]);
    x
end

